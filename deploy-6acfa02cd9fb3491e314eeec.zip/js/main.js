/* Shared header / footer / WhatsApp + page logic */
(function () {
  const page = document.body.dataset.page || "";
  const links = [["index.html","HOME"],["catalogue.html","CATALOGUE"],["journal.html","JOURNAL"],["about.html","ABOUT"],["contact.html","CONTACT"]];

  const nav = document.createElement("header");
  nav.className = "nav" + (document.body.dataset.hero === "dark" ? " dark-hero" : "");
  nav.innerHTML = `<div class="container">
    <a href="index.html" class="logo">RADHIKA STONEX<small>CURATORS OF NATURAL STONE</small></a>
    <ul>${links.map(([h,t]) => `<li><a href="${h}" class="${h.startsWith(page)?"active":""}">${t}</a></li>`).join("")}</ul>
    <a href="${WA_GENERAL}" target="_blank" rel="noopener" class="btn cta">ENQUIRE ↗</a>
    <button class="burger" aria-label="Menu">☰</button></div>`;
  document.body.prepend(nav);
  nav.querySelector(".burger").onclick = () => nav.classList.toggle("open");
  const onScroll = () => nav.classList.toggle("scrolled", scrollY > 60);
  addEventListener("scroll", onScroll); onScroll();

  const footer = document.createElement("footer");
  footer.innerHTML = `<div class="container">
    <div class="big">RADHIKA STONEX</div>
    <div class="cols">
      <div><h5>STUDIO</h5><p>G-208, 209 & 210, IIIrd Phase,<br>RIICO Industrial Area, Kishangarh,<br>Rajasthan – 305801, India</p></div>
      <div><h5>COLLECTIONS</h5><ul>${COLLECTIONS.map(c=>`<li><a href="${c.catalogue}" target="_blank" rel="noopener">${c.name}</a></li>`).join("")}</ul></div>
      <div><h5>EXPLORE</h5><ul>${links.slice(1).map(([h,t])=>`<li><a href="${h}">${t}</a></li>`).join("")}</ul></div>
      <div><h5>CONTACT</h5><ul><li><a href="mailto:info@radhikastonex.com">info@radhikastonex.com</a></li><li><a href="tel:+919891725715">+91 98917 25715</a></li><li><a href="tel:+918800722241">+91 88007 22241</a></li><li><a href="${WA_GENERAL}" target="_blank">WhatsApp ↗</a></li></ul></div>
    </div>
    <div class="copy"><span>© ${new Date().getFullYear()} Radhika Stonex. All rights reserved.</span><span>www.radhikastonex.com</span></div></div>`;
  document.body.append(footer);

  const wa = document.createElement("a");
  wa.className = "wa"; wa.href = WA_GENERAL; wa.target = "_blank"; wa.rel = "noopener"; wa.setAttribute("aria-label","Chat on WhatsApp");
  wa.innerHTML = `<svg viewBox="0 0 32 32"><path d="M16 3C9 3 3.3 8.6 3.3 15.6c0 2.5.7 4.8 1.9 6.8L3 29l6.8-2.2c1.9 1 4 1.6 6.2 1.6 7 0 12.7-5.7 12.7-12.7S23 3 16 3zm0 23.2c-2 0-3.9-.6-5.5-1.6l-.4-.2-4 1.3 1.3-3.9-.3-.4a10.4 10.4 0 1 1 8.9 4.8zm5.7-7.8c-.3-.2-1.9-.9-2.2-1-.3-.1-.5-.2-.7.2s-.8 1-1 1.2c-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.6-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.6c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.6l-1-2.4c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-.3.3-1.2 1.1-1.2 2.8s1.2 3.2 1.4 3.5c.2.2 2.4 3.7 5.8 5.1 2.9 1.1 3.4.9 4 .8.6-.1 1.9-.8 2.2-1.5.3-.7.3-1.4.2-1.5-.1-.2-.3-.3-.6-.4z"/></svg>`;
  document.body.append(wa);

  // reveal on scroll
  const io = new IntersectionObserver((es) => es.forEach(e => e.isIntersecting && e.target.classList.add("in")), { threshold: .15 });
  const observe = () => document.querySelectorAll(".reveal,.step").forEach(el => io.observe(el));
  observe();

  // hero parallax / 3D tilt
  const hb = document.querySelector(".hero-bg");
  if (hb && matchMedia("(pointer:fine)").matches) {
    addEventListener("mousemove", (e) => {
      const x = (e.clientX / innerWidth - .5) * 6, y = (e.clientY / innerHeight - .5) * 6;
      hb.style.translate = `${-x}px ${-y}px`;
    });
  }

  const collCard = (c) => `<a href="${c.catalogue}" target="_blank" rel="noopener" class="coll reveal">
    <img src="${c.img}" alt="${c.sub}" loading="lazy"><div class="info">
    <div class="eyebrow">${c.sub}</div><h3>${c.name}</h3><p>${c.desc}</p>
    <div class="meta"><span>${PRODUCTS.filter(p=>p.collection===c.slug).length} Materials</span><span>View Catalogue ↗</span></div></div></a>`;

  document.querySelectorAll("[data-collections]").forEach(el => { el.innerHTML = COLLECTIONS.map(collCard).join(""); observe(); });
  // journal
  const jCard=(a,cls="")=>`<a href="article.html?id=${a.id}" class="j-card reveal ${cls}"><div class="ph"><img src="${a.img}" alt="${a.title}" loading="lazy"></div><div class="eyebrow">${a.tag} · ${a.read} min read</div><h3>${a.title}</h3><p>${a.sub}</p></a>`;
  const jg=document.getElementById("journal-grid");
  if(jg){jg.innerHTML=jCard(ARTICLES[0],"j-lead")+ARTICLES.slice(1).map(a=>jCard(a)).join("");observe();}
  document.querySelectorAll("[data-journal]").forEach(el=>{el.innerHTML=ARTICLES.slice(0,3).map(a=>jCard(a)).join("");observe();});
  const ar=document.getElementById("article");
  if(ar){const a=ARTICLES.find(x=>x.id===new URLSearchParams(location.search).get("id"))||ARTICLES[0];document.title=`${a.title} | Radhika Stonex Journal`;
    const fig=(src,cap)=>`<figure><img src="${src}" alt="${cap}" loading="lazy"><figcaption>${cap}</figcaption></figure>`;
    const block=b=>typeof b==="string"?`<p>${b}</p>`:b.h?`<h2>${b.h}</h2>`:b.img?fig(b.img,b.cap):b.gallery?`<div class="a-gallery">${b.gallery.map(([s,c])=>fig(s,c)).join("")}</div>`:b.quote?`<blockquote>“${b.quote}”</blockquote>`:b.list?`<ul>${b.list.map(l=>`<li>${l}</li>`).join("")}</ul>`:b.tip?`<aside class="a-tip"><div class="eyebrow">Radhika Stonex tip</div><p>${b.tip}</p></aside>`:"";
    const i=ARTICLES.indexOf(a),next=ARTICLES[(i+1)%ARTICLES.length];
    ar.innerHTML=`<header class="a-head"><div class="eyebrow">${a.tag} · ${a.date} · ${a.read} min read</div><h1>${a.title}</h1><p class="a-sub">${a.sub}</p></header>
      <img class="a-hero" src="${a.img}" alt="${a.title}"><div class="a-body">${a.body.map(block).join("")}
      <div class="a-cta"><a class="btn" href="journal.html">← All articles</a><a class="btn btn-solid" href="${WA_GENERAL}" target="_blank" rel="noopener">Ask us on WhatsApp ↗</a></div></div>
      <a class="a-next" href="article.html?id=${next.id}"><div class="eyebrow">Next article</div><h3>${next.title} →</h3></a>`;
    observe();}

  // catalogue
  const cl = document.getElementById("catalogue-list");
  if (cl) {
    cl.innerHTML = COLLECTIONS.map((c,i) => `<a class="cat-item reveal" href="${c.catalogue}" target="_blank" rel="noopener">
      <img src="${c.img}" alt="${c.name}" loading="lazy"><div><div class="eyebrow">0${i+1} · ${c.country}</div><h3>${c.name}</h3></div>
      <p style="color:var(--muted)">${c.sub} — ${c.desc}</p><span class="btn">View PDF ↗</span></a>`).join("");
    observe();
  }

  // contact form → WhatsApp
  const form = document.getElementById("enquiry");
  if (form) form.onsubmit = (e) => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(form));
    const msg = `Hello Radhika Stonex,\nName: ${d.name}\nPhone: ${d.phone}\nEmail: ${d.email}\nI am a: ${d.role}\nInterested in: ${d.interest}\n${d.message}`;
    window.open(waLink(msg), "_blank");
  };
})();
