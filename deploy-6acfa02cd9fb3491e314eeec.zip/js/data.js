/* =========================================================
   RADHIKA STONEX — PRODUCT DATABASE
   Edit this file to add / remove / update materials.
   Each product: [name, materialType, colour, finishes, featured?]
   Images default to the collection image — replace `img` per
   product in PRODUCTS below with real slab photos when available.
   ========================================================= */

const WHATSAPP = "919891725715";

const DRIVE = (id) => `https://drive.google.com/file/d/${id}/view`;

const COLLECTIONS = [
  { slug: "italiano", name: "ITALIANO", sub: "Italian Marble", country: "Italy", img: "images/italiano.jpg",
    desc: "Carrara's quiet light. The marbles that shaped the Renaissance.", catalogue: DRIVE("1YBiEkVQ8d9bZkbzmZe9MP9prt1mwO2JX") },
  { slug: "anatolia", name: "ANATOLIA", sub: "Turkish Marble", country: "Turkey", img: "images/anatolia.jpg",
    desc: "Warm earth tones from the ancient quarries of Asia Minor.", catalogue: DRIVE("1-v29AQ3aSDpbCsKk4r-vhyasNzd6wejA") },
  { slug: "brazil", name: "BRASILIA", sub: "Brazilian Marble & Exotic Stone", country: "Brazil", img: "images/brazil.jpg",
    desc: "Quartzites of impossible colour, born under tropical earth.", catalogue: DRIVE("1fFz7hpLXeH0m5LFgTBTHeojkV0OumdTU") },
  { slug: "vietnam", name: "ANNAM", sub: "Vietnamese Marble", country: "Vietnam", img: "images/vietnam.jpg",
    desc: "Crystalline whites of luminous purity from Yen Bai.", catalogue: DRIVE("1hZQZRBJidPEnNdoApwvlSQNUDsTHA_15") },
  { slug: "iran", name: "PERSIA", sub: "Iranian Marble", country: "Iran", img: "images/iran.jpg",
    desc: "Honeyed onyx and travertine from the Persian plateau.", catalogue: DRIVE("17hHhZaAbxAmLAAGpnkk9P6dreYTVcGv8") },
  { slug: "granito", name: "GRANITO", sub: "Rajasthan Granite", country: "Rajasthan", img: "images/granito.jpg",
    desc: "Enduring strength from the heart of Rajasthan.", catalogue: DRIVE("1j3rSKR0d21NHoAqD__yl3RObf8ZHn9qK") },
];

const RAW = {
  italiano: [
    ["Statuario", "Marble", "White", "Polished, Honed", 1], ["Calacatta Gold", "Marble", "White", "Polished, Honed", 1],
    ["Calacatta Borghini", "Marble", "White", "Polished"], ["Calacatta Oro", "Marble", "White", "Polished"],
    ["Carrara White", "Marble", "White", "Polished, Honed"], ["Arabescato Corchia", "Marble", "White", "Polished"],
    ["Arabescato Vagli", "Marble", "White", "Polished"], ["Bianco Lasa", "Marble", "White", "Polished, Honed"],
    ["Statuarietto", "Marble", "White", "Polished"], ["Calacatta Viola", "Marble", "Multicolour", "Polished", 1],
    ["Breccia Capraia", "Marble", "Multicolour", "Polished"], ["Breccia Oniciata", "Marble", "Beige", "Polished"],
    ["Botticino Classico", "Marble", "Beige", "Polished, Honed"], ["Perlato Sicilia", "Marble", "Cream", "Polished"],
    ["Travertino Romano", "Natural Stone", "Beige", "Honed, Filled"], ["Grigio Carnico", "Marble", "Grey", "Polished"],
    ["Bardiglio Nuvolato", "Marble", "Grey", "Polished, Honed"], ["Nero Marquina (Italian cut)", "Marble", "Black", "Polished"],
    ["Rosso Levanto", "Marble", "Red", "Polished"], ["Verde Alpi", "Marble", "Green", "Polished"],
    ["Fior di Pesco Carnico", "Marble", "Grey", "Polished"],
  ],
  anatolia: [
    ["Emperador Light", "Marble", "Brown", "Polished", 1], ["Emperador Dark", "Marble", "Brown", "Polished"],
    ["Burdur Beige", "Marble", "Beige", "Polished, Honed"], ["Botticino Turkish", "Marble", "Beige", "Polished"],
    ["Crema Nuova", "Marble", "Cream", "Polished"], ["Ivory Cream", "Marble", "Cream", "Polished"],
    ["Diana Royal", "Marble", "Beige", "Polished"], ["Diana Gold", "Marble", "Beige", "Polished"],
    ["Rosalia", "Marble", "Beige", "Polished"], ["Tundra Grey", "Marble", "Grey", "Polished, Honed", 1],
    ["Fendi Grey", "Marble", "Grey", "Polished"], ["Kanfanar Grey", "Marble", "Grey", "Polished"],
    ["Silver Travertine", "Natural Stone", "Grey", "Honed, Filled"], ["Ivory Travertine", "Natural Stone", "Beige", "Honed, Filled"],
    ["Afyon White", "Marble", "White", "Polished"], ["Afyon Sugar", "Marble", "White", "Polished, Honed"],
    ["Mugla White", "Marble", "White", "Polished"], ["Elazig Cherry", "Marble", "Red", "Polished"],
    ["Black Oyster", "Marble", "Black", "Polished"], ["Rainforest Green (Turkish)", "Marble", "Green", "Polished"],
  ],
  brazil: [
    ["Taj Mahal Quartzite", "Quartzite", "Cream", "Polished, Leather", 1], ["Patagonia", "Exotic Stone", "Multicolour", "Polished", 1],
    ["Blue Roma", "Quartzite", "Blue", "Polished"], ["Azul Macaubas", "Quartzite", "Blue", "Polished"],
    ["Cristallo", "Quartzite", "White", "Polished"], ["Mont Blanc", "Quartzite", "White", "Polished, Leather"],
    ["White Macaubas", "Quartzite", "White", "Polished"], ["Fusion", "Quartzite", "Multicolour", "Polished"],
    ["Van Gogh", "Exotic Stone", "Multicolour", "Polished"], ["Perla Venata", "Quartzite", "Grey", "Polished"],
    ["Sea Pearl", "Quartzite", "Grey", "Leather"], ["Black Taurus", "Granite", "Black", "Polished"],
    ["Titanium Black", "Granite", "Black", "Polished, Leather"], ["Belvedere", "Quartzite", "Black", "Polished"],
    ["Verde Lapponia", "Granite", "Green", "Polished"], ["Ubatuba", "Granite", "Green", "Polished"],
    ["Amazonite", "Exotic Stone", "Green", "Polished"], ["Labradorite Blue", "Exotic Stone", "Blue", "Polished"],
    ["Copacabana", "Granite", "Black", "Polished"], ["Alpinus", "Granite", "Grey", "Polished"],
    ["Wakanda", "Exotic Stone", "Grey", "Polished"],
  ],
  vietnam: [
    ["Crystal White", "Marble", "White", "Polished", 1], ["Vietnam White", "Marble", "White", "Polished, Honed"],
    ["Snow White", "Marble", "White", "Polished"], ["Volakas Vietnam", "Marble", "White", "Polished"],
    ["Yen Bai Pure White", "Marble", "White", "Polished"], ["Grey Crystal", "Marble", "Grey", "Polished"],
    ["Cloudy Grey", "Marble", "Grey", "Polished, Honed"], ["Silver Grey", "Marble", "Grey", "Polished"],
    ["Pink Vietnam", "Marble", "Multicolour", "Polished"], ["Beige Vietnam", "Marble", "Beige", "Polished"],
    ["Black Vietnam", "Marble", "Black", "Polished"], ["Bluestone Vietnam", "Natural Stone", "Grey", "Honed"],
    ["Basalt Vietnam", "Natural Stone", "Black", "Honed"], ["Green Onyx Vietnam", "Exotic Stone", "Green", "Polished"],
    ["Ivory Vietnam", "Marble", "Cream", "Polished"], ["Crystal Grey Vein", "Marble", "White", "Polished"],
  ],
  iran: [
    ["Persian White Onyx", "Exotic Stone", "White", "Polished", 1], ["Honey Onyx", "Exotic Stone", "Beige", "Polished", 1],
    ["Afghan Green Onyx", "Exotic Stone", "Green", "Polished"], ["Silver Travertine Persian", "Natural Stone", "Grey", "Honed"],
    ["Persian Red Travertine", "Natural Stone", "Red", "Honed, Filled"], ["Classic Travertine", "Natural Stone", "Beige", "Honed, Filled"],
    ["Golden Travertine", "Natural Stone", "Beige", "Honed"], ["Dehbid Cream", "Marble", "Cream", "Polished"],
    ["Omani Beige (Persian)", "Marble", "Beige", "Polished"], ["Crema Persia", "Marble", "Cream", "Polished"],
    ["Persian Grey", "Marble", "Grey", "Polished"], ["Armani Grey", "Marble", "Grey", "Polished"],
    ["Persian Black", "Marble", "Black", "Polished"], ["Persian Emperador", "Marble", "Brown", "Polished"],
    ["Persian Silk", "Marble", "Beige", "Polished"], ["Azarshahr Red", "Natural Stone", "Red", "Honed"],
  ],
  granito: [
    ["Absolute Black", "Granite", "Black", "Polished, Leather, Flamed", 1], ["Jet Black", "Granite", "Black", "Polished"],
    ["Rajasthan Black", "Granite", "Black", "Polished, Flamed"], ["Black Pearl", "Granite", "Black", "Polished"],
    ["Black Galaxy", "Granite", "Black", "Polished", 1], ["Steel Grey", "Granite", "Grey", "Polished, Flamed"],
    ["Sadarahalli Grey", "Granite", "Grey", "Polished"], ["Rosy Pink", "Granite", "Red", "Polished, Flamed"],
    ["Lakha Red", "Granite", "Red", "Polished"], ["Jhansi Red", "Granite", "Red", "Polished"],
    ["Ruby Red", "Granite", "Red", "Polished"], ["Chima Pink", "Granite", "Red", "Polished, Flamed"],
    ["Royal Cream", "Granite", "Cream", "Polished"], ["Crystal Yellow", "Granite", "Beige", "Polished"],
    ["Alaska White", "Granite", "White", "Polished"], ["Coffee Brown", "Granite", "Brown", "Polished"],
    ["Tan Brown", "Granite", "Brown", "Polished"], ["Tiger Skin", "Granite", "Multicolour", "Polished"],
    ["Imperial White", "Granite", "White", "Polished"], ["Forest Green", "Granite", "Green", "Polished"],
    ["Raw Silk", "Granite", "Multicolour", "Polished"],
  ],
};

const slugify = (s) => s.toLowerCase().replace(/\(.*?\)/g, "").trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const PRODUCTS = [];
COLLECTIONS.forEach((c) => {
  RAW[c.slug].forEach(([name, type, colour, finish, featured]) => {
    PRODUCTS.push({
      id: `${c.slug}-${slugify(name)}`,
      name, collection: c.slug, collectionName: c.name, country: c.country,
      type, colour, finish: finish.split(",").map((f) => f.trim()),
      applications: type === "Granite" ? ["Flooring", "Kitchen", "Facade", "Staircase"] : ["Flooring", "Wall Cladding", "Bathroom", "Feature Wall"],
      short: `${colour} ${type.toLowerCase()} from ${c.country}.`,
      long: `${name} is a ${colour.toLowerCase()} ${type.toLowerCase()} sourced from ${c.country}, selected block by block by Radhika Stonex for architectural and luxury residential projects. Slab sizes, thickness and availability vary by lot — enquire for current stock.`,
      img: c.img, featured: !!featured,
    });
  });
});

const waLink = (msg) => `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`;
const WA_GENERAL = waLink("Hello Radhika Stonex, I would like to enquire about your marble and natural stone collection.");
const waProduct = (name) => waLink(`Hello Radhika Stonex, I am interested in ${name}. Please share availability, specifications and slab details.`);

/* Journal articles. Body blocks: "text" = paragraph, {h} heading, {img,cap} photo,
   {gallery:[[src,cap],...]} photo row, {quote}, {list:[...]}, {tip} highlighted note. */
const J = "images/journal/";
const ARTICLES=[
{
id: "statuario-vs-calacatta", img: "images/italiano.jpg", tag: "Guide", date: "September 2026", read: 7,
title: "Statuario vs Calacatta: reading the vein",
sub: "How to tell Italy's two most coveted whites apart, and choose between them.",
body: [
"Both stones come from the Apuan Alps around Carrara, a range of mountains that has been quarried for more than two thousand years. Both have a bright white background, and both are among the most requested materials in luxury interiors today. Yet once you learn to read the vein, they could hardly be more different.",
{h: "Statuario: the calm white"},
"Statuario has thin, sharp grey veins spread across a very white, almost luminous base. The veining is usually more delicate and evenly distributed, which gives the slab a quiet, classical feel. It is the stone of Michelangelo's David, and it still carries that sense of restraint.",
"Because the pattern is gentle, Statuario suits large continuous surfaces — floors that run through an entire apartment, full-height bathroom walls and staircases where you want the stone to feel seamless.",
{img: J+"white-bathroom.jpg", cap: "A white marble bathroom — soft veining keeps a small room feeling open and bright."},
{h: "Calacatta: the statement white"},
"Calacatta has bolder, thicker veins, often with gold, beige or even violet tones running through the white. Where Statuario whispers, Calacatta speaks. Each slab has strong movement, and no two look alike.",
"This makes it ideal for one hero surface: a kitchen island, a fireplace surround, a vanity or a feature wall behind a bed. Used on every surface it can feel busy; used in one place it becomes the centrepiece of the room.",
{gallery: [[J+"white-kitchen.jpg", "Kitchen islands are the classic home for Calacatta."], [J+"feature-wall.jpg", "Bold veining reads best on a single feature wall."]]},
{quote: "Statuario is a backdrop. Calacatta is the painting hung on it."},
{h: "Side by side"},
{list: ["Background: Statuario is cooler and whiter; Calacatta can be slightly warmer.", "Veins: Statuario has fine grey veins; Calacatta has wide, dramatic veins, often gold.", "Best for: Statuario on large floors and walls; Calacatta on islands, vanities and feature walls.", "Price: both are premium; top-grade Calacatta with gold veining is usually the rarest."]},
{tip: "Always ask to see the full slab, not just a small sample. Veining changes a lot from one block to the next, and book-matched slabs need planning before cutting. We are happy to share slab photos on WhatsApp before you visit."}
]
},
{
id: "quartzite", img: "images/brazil.jpg", tag: "Material", date: "August 2026", read: 6,
title: "Why architects are turning to quartzite",
sub: "The hardness of granite with the look of marble.",
body: [
"Quartzite starts life as sandstone. Over millions of years, heat and pressure deep underground fuse its quartz grains together until it becomes one of the hardest natural stones used in architecture — far harder than marble, and often harder than granite.",
{h: "Built for the kitchen"},
"It resists scratches and heat better than marble, which is why it has become a favourite for kitchen countertops. A hot pan, a dropped knife or daily chopping will not mark it the way softer stones can.",
{img: J+"white-kitchen.jpg", cap: "Light quartzites such as Taj Mahal and Mont Blanc give a marble look with far greater durability."},
"Quartzite is also less sensitive to acids such as lemon juice or vinegar, though it is not completely immune. A good sealer keeps it practically worry-free.",
{h: "Brazil's colour palette"},
"Brazil supplies some of the most dramatic quartzites in the world. Taj Mahal offers soft cream with gentle gold movement; Cristallo is almost translucent white; Blue Roma and Azul Macaubas bring deep, oceanic blues; Fusion and Patagonia combine many colours in a single slab.",
{gallery: [["images/brazil.jpg", "Exotic Brazilian quartzite slab."], [J+"lounge.jpg", "Dark living spaces pair beautifully with bold quartzite."]]},
{quote: "Quartzite lets you have the marble look in places where marble would struggle."},
{h: "Where to use it"},
{list: ["Kitchen countertops and islands", "Outdoor kitchens and bar counters", "High-traffic floors in lobbies", "Backlit panels (selected translucent varieties)"]},
{tip: "Not every stone sold as quartzite really is one — some are softer marbles. Ask your supplier for a scratch test on glass: true quartzite will scratch glass easily."}
]
},
{
id: "kishangarh", img: "images/quarry.jpg", tag: "Origin", date: "July 2026", read: 6,
title: "Kishangarh: India's marble capital",
sub: "Inside one of the world's largest marble markets.",
body: [
"Kishangarh in Rajasthan is home to thousands of marble and granite traders, processors and stockyards. Driving through the industrial area, you pass kilometre after kilometre of slabs standing in the sun, from snow-white Vietnamese marble to jet-black Rajasthan granite.",
{h: "A global stone hub"},
"Blocks arrive here from quarries across India and from Italy, Turkey, Iran, Vietnam and Brazil. Gang saws and block cutters run day and night, turning rough blocks into slabs that are then polished, honed or leathered on site.",
{img: "images/quarry.jpg", cap: "Raw blocks are selected at the quarry before being shipped to Kishangarh for cutting."},
"Because so many suppliers sit side by side, Kishangarh offers a range that is hard to match anywhere else, and prices that are highly competitive.",
{quote: "In one morning in Kishangarh you can see more stone than most cities show in a year."},
{h: "Visiting the yard"},
"Architects, designers and homeowners often visit to choose their slabs in person. It is the best way to judge colour, veining and finish under daylight, and to reserve book-matched sets for a project.",
{gallery: [["images/granito.jpg", "Rajasthan granite, cut and polished locally."], ["images/anatolia.jpg", "Imported Turkish marble awaiting selection."]]},
{list: ["Plan your visit in the morning, when the light is softest.", "Bring your drawings so quantities can be calculated on the spot.", "Photograph and number the slabs you reserve."]},
{tip: "Radhika Stonex works from RIICO Industrial Area, Kishangarh, so we can source, inspect and dispatch slabs quickly. Message us on WhatsApp to arrange a guided slab-selection visit."}
]
},
{
id: "backlit-onyx", img: "images/iran.jpg", tag: "Design", date: "June 2026", read: 5,
title: "Backlit onyx in hotels and restaurants",
sub: "Translucent stone that glows.",
body: [
"Onyx is one of the few natural stones that lets light pass through it. With LED panels placed behind it, a wall, bar counter or reception desk glows with warm amber, honey or green colour, revealing bands and clouds hidden inside the stone.",
{img: J+"resort.jpg", cap: "Resorts and hotels use backlit onyx to create a warm, memorable first impression."},
{h: "Where designers use it"},
"Backlit onyx appears in hotel lobbies, bars, spas, restaurants and premium bathrooms. It is a material of atmosphere: in daylight it looks like a rich patterned stone, and at night it turns into a glowing work of art.",
{list: ["Reception desks and lobby feature walls", "Bar fronts and back-bars", "Spa and hammam walls", "Bathroom vanities and shower niches"]},
{quote: "By day it is stone. By night it is light."},
{h: "Practical notes"},
"Onyx is softer than marble, so it is best on walls and counters that do not get heavy wear. It is usually supplied with a resin-backed mesh for strength, and the slab is often cut thinner for the best glow.",
{gallery: [["images/iran.jpg", "Persian honey onyx."], [J+"lounge.jpg", "Low ambient light lets onyx take centre stage."]]},
{tip: "Plan the lighting with your installer early. Slab thickness, LED colour temperature and the gap between light and stone all change the final glow — we can share mock-up photos before you buy."}
]
},
{
id: "finishes", img: "images/granito.jpg", tag: "Care", date: "May 2026", read: 6,
title: "Polished, honed or leathered?",
sub: "A simple guide to stone finishes.",
body: [
"The same block of stone can look completely different depending on how its surface is finished. Choosing the right finish is as important as choosing the stone itself — it affects colour, safety, maintenance and the feeling of a room.",
{h: "Polished"},
"Glossy and reflective. Polishing brings out the deepest colour and sharpest veining, and makes rooms feel brighter. It suits living rooms, walls and vanities, but can be slippery when wet.",
{img: J+"living.jpg", cap: "Polished floors reflect light and make living spaces feel larger."},
{h: "Honed"},
"Smooth and matte. Honed stone hides scratches and etching better, and offers more grip underfoot, so it is a good choice for floors, bathrooms and busy homes.",
{img: J+"dark-bathroom.jpg", cap: "Honed stone gives bathrooms a soft, calm and safer surface."},
{h: "Leathered"},
"Lightly textured and soft to the touch. Leathering hides fingerprints and water marks and works especially well on dark granites and quartzites for kitchen counters.",
{h: "Flamed"},
"A rough, non-slip texture created with intense heat. Mostly used on granite for outdoor paving, pool decks and facades.",
{gallery: [[J+"facade.jpg", "Flamed granite is ideal for exteriors and facades."], [J+"staircase.jpg", "Honed or leathered treads are safer on stairs."]]},
{h: "Caring for any finish"},
{list: ["Clean with a mild, pH-neutral cleaner — never acid or bleach.", "Wipe spills quickly, especially wine, oil and citrus.", "Reseal every one to two years, or when water stops beading.", "Use mats at entrances to keep grit off polished floors."]},
{tip: "Ask for a sample in two finishes and look at them in your own room's light. The difference is often bigger than you expect."}
]
},
{
id: "crystalline-whites", img: "images/vietnam.jpg", tag: "Trend", date: "April 2026", read: 5,
title: "The quiet luxury of crystalline whites",
sub: "Vietnamese marble and the minimalist interior.",
body: [
"Vietnamese white marble, mostly quarried in the Yen Bai province, has a fine, sparkling crystal structure and very little veining. In sunlight its surface seems to shimmer, which is why it is often called crystal white.",
{img: J+"feature-wall.jpg", cap: "Clean white stone suits calm, minimal interiors."},
{h: "Made for minimalism"},
"It suits clean, minimal homes where the stone should feel pure rather than busy. Paired with light timber, linen and plaster walls, it creates the soft, quiet luxury that many homeowners now prefer over dramatic veining.",
{quote: "Sometimes the most luxurious stone is the one that doesn't shout."},
{h: "Value and versatility"},
"It is often more affordable than Italian whites while giving a similar bright look. Large block sizes also mean consistent slabs for big projects, so a whole floor can match from room to room.",
{gallery: [[J+"staircase.jpg", "Staircases and landings in crystalline white."], [J+"white-bathroom.jpg", "Bright bathroom walls and floors."]]},
{list: ["Large-format flooring", "Staircases and landings", "Wall cladding in homes and offices", "Bathrooms and vanities"]},
{tip: "Crystalline whites are a little more porous than dense Italian marbles. Seal before installation and again after grouting for the best result."}
]
}
];
