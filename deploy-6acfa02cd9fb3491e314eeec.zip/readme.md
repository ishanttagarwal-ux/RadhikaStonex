# Radhika Stonex — Website (static, no build step)

## Deploy (GitHub + Netlify)
1. Create a new GitHub repo, upload ALL files in this folder (keep folder structure).
2. Netlify → Add new site → Import from GitHub → pick the repo.
   Build command: (leave empty) · Publish directory: `.`
3. Or just drag this folder onto https://app.netlify.com/drop

## IMPORTANT — Catalogue PDFs
Catalogue buttons open your Google Drive PDFs. In Google Drive, set each PDF
(RadhikaStonex/Collections/*) to "Anyone with the link → Viewer", otherwise visitors can't open them.

## Editing
- Products / collections / WhatsApp number / catalogue links: `js/data.js`
- Colours & fonts: top of `css/style.css`
- Header/footer/WhatsApp button: `js/main.js`
- Product images currently reuse the 6 collection images. Add real slab photos
  into `/images` and set `img` per product in `js/data.js`.

## Still to do (for the next AI / developer)
- Real slab photos for every product
- Replace YOUR-SITE in sitemap.xml and robots.txt with your Netlify address
- Optional: pretty URLs (/products/italiano/statuario)
- Verify stone list with the owner (names are common Kishangarh trade names)
